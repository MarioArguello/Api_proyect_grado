const { dirname } = require('path');
const path = require('path')

module.exports = function (app) {
    const Amigo = require(path.resolve(__dirname, '../components/amigo/controller.js'))
    const Comentario = require(path.resolve(__dirname, '../components/comentario/controller.js'))
    const Historialpersona = require(path.resolve(__dirname, '../components/historialpersona/controller.js'))
    const Like = require(path.resolve(__dirname, '../components/like/controller.js'))
    const Persona = require(path.resolve(__dirname, '../components/persona/controller.js'))
    const Tweet = require(path.resolve(__dirname, '../components/tweet/controller.js'))
    const Usuario = require(path.resolve(__dirname, '../components/usuario/controller.js'))
    const Proceso = require(path.resolve(__dirname, '../components/procesos/controller.js'))
    /* CRUD AMIGO */
    app.delete('/amigo/delete/:idpersona/:idpersonaamigo', Amigo.delete)
    app.post('/amigo/create', Amigo.create)

    ///* --------------------- */
    app.get('/amigo/get/:idamigo', Amigo.filter)
    app.get('/amigo/getAll', Amigo.findAll)
    app.put('/amigo/update/:idamigo', Amigo.update)
   

    /* CRUD COMENTARIO */
    app.post('/comentario/create', Comentario.create)
    app.get('/comentario/get/:idcomentario', Comentario.filter)
    app.get('/comentario/getAll', Comentario.findAll)
    app.put('/comentario/update/:idcomentario', Comentario.update)
    app.delete('/comentario/delete/:idcomentario', Comentario.delete)

    /* CRUD Historialpersona */
    app.post('/historialpersona/create', Historialpersona.create)
    app.delete('/historialpersona/delete/:idpersona/:idpersonabusqueda', Historialpersona.delete)
    

    app.get('/historialpersona/get/:idhistorial', Historialpersona.filter)
    app.get('/historialpersona/getAll', Historialpersona.findAll)
    app.put('/historialpersona/update/:idhistorial', Historialpersona.update)
   

     /* CRUD Like */
     app.post('/like/create', Like.create)
     app.get('/like/get/:idlike', Like.filter)
     app.get('/like/getAll', Like.findAll)
     app.put('/like/update/:idlike', Like.update)
     app.delete('/like/delete/:idlike', Like.delete)

      /* CRUD Persona */
      //app.post('/persona/create',Persona.upload, Persona.create)
      app.post('/persona/create', Persona.create)
      app.get('/persona/get/:idpersona', Persona.filter)
      app.get('/persona/getAll', Persona.findAll)
      app.put('/persona/update/:idpersona', Persona.update)
      app.delete('/persona/delete/:idpersona', Persona.delete)


      /* CRUD Tweet */
      app.post('/tweet/create', Tweet.create)
      app.put('/tweet/update/:idtweet', Tweet.update)

      // 
      app.get('/tweet/get/:idtweet', Tweet.filter)
      app.get('/tweet/getAll', Tweet.findAll)
      
      app.delete('/tweet/delete/:idtweet', Tweet.delete)

      /* CRUD Usuario */
      app.post('/usuario/create', Usuario.create)
      app.get('/usuario/get/:idusuario', Usuario.filter)
      app.get('/usuario/getAll', Usuario.findAll)
      app.put('/usuario/update/:idusuario', Usuario.update)
      app.delete('/usuario/delete/:idusuario', Usuario.delete)

      /* CRUD ENTRE TABLAS */ 
      app.get('/proceso/validarPersona/:dni/:telefono', Proceso.filterRegistro)
      /* correo filterRegistroCorreo*/
      app.get('/proceso/validarPersonaCorreo/:correo', Proceso.filterRegistroCorreo)

      //crear persona
      app.post('/proceso/persona__usuario_crear/create', Proceso.create_persona)
      // loqueo inicio.
      app.get('/proceso/login/:username/:password', Proceso.filter)
      // tweet de la persona logueada
      app.get('/proceso/TweetAllPerson', Proceso.filterpersonaTweetAll)
      // Comentarios de los tweet
      app.get('/proceso/Comentario_tweet/:idtweet', Proceso.filterComentarioTweet)
      // Tweet activos  de la persona logeada
      app.get('/proceso/tweet_persona/:idpersona', Proceso.tweet_persona)
     // tweet desactivados de la persona logeada tweetDesactivado_persona
     app.get('/proceso/tweetDesactivado_persona/:idpersona', Proceso.tweetDesactivado_persona)
     
      app.get('/proceso/persona_perfil/:idpersona', Proceso.perfil_persona)
      // tweet de amigos
      app.get('/proceso/tweet_amigo/:idpersona', Proceso.tweet_persona_amigo)
      // like de tweet
      app.get('/proceso/filtrodeLike/:idpersona/:idtweet',Proceso.filter_like_existente)
      //historial persona Historialpersona_
      app.get('/proceso/historialpersona/:idpersona',Proceso.Historialpersona_)
      //busqueda de personas busqueda_persona
      app.get('/proceso/busqueda_nombre/:nombres',Proceso.busqueda_persona)
      // validar si es amigo o no para poder agregar validaramigopersona
      app.get('/proceso/validar_amigo_persona/:idpersona/:idpersonaamigo',Proceso.validaramigopersona)
    //invitar persona invitar_personas
    app.get('/proceso/invitarpersona/getaAll',Proceso.invitar_personas)
    }
