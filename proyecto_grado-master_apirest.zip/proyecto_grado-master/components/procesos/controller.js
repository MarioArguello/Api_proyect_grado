const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Persona = db.persona;
const Usuario = db.usuario;
const Amigo = db.amigo;
const Tweet = db.tweet;
const Like = db.like;
const Comentario = db.comentario;
const Historialpersona = db.historialpersona;

// asociaciones
Persona.belongsTo(Usuario, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})

Usuario.belongsTo(Persona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})

Persona.belongsTo(Amigo, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})

Amigo.belongsTo(Persona, {
    foreignKey: 'idpersonaamigo',
    sourceKey: 'idpersonaamigo',
    targetKey: 'idpersona'
})

Tweet.hasOne(Persona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})

Persona.hasMany(Tweet, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})




// like

Like.hasOne(Tweet, {
    foreignKey: 'idtweet',
    sourceKey: 'idtweet',
    targetKey: 'idtweet'
})
Tweet.hasMany(Like, {
    foreignKey: 'idtweet',
    sourceKey: 'idtweet',
    targetKey: 'idtweet'
})

//Comentario

Comentario.belongsTo(Tweet, {
    foreignKey: 'idtweet',
    sourceKey: 'idtweet',
    targetKey: 'idtweet'
})
Tweet.belongsTo(Comentario, {
    foreignKey: 'idtweet',
    sourceKey: 'idtweet',
    targetKey: 'idtweet'
})



//Like - Persona

Like.hasOne(Persona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})
Persona.hasMany(Like, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})

// Comentario - Persona

Comentario.belongsTo(Persona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})
Persona.belongsTo(Comentario, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})


//Historial Persona 

Persona.hasMany(Historialpersona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersona',
    targetKey: 'idpersona'
})
Historialpersona.hasOne(Persona, {
    foreignKey: 'idpersona',
    sourceKey: 'idpersonabusqueda',
    targetKey: 'idpersona'
})


// consultas 

// Login 
exports.filter = (req, res) => {
    Usuario.findAll({
        where: {
            username: req.params.username
        },
    }).then(usuario_login => {
        if (usuario_login.length > 0) {
            if (usuario_login[0].dataValues.password == req.params.password) {
                res.json(
                    {
                        "msg": "1",
                        "id_person": usuario_login[0].dataValues.idpersona,
                    }
                )
            } else {
                res.json(
                    {
                        "msg": "constraseña incorrecta"
                    }
                )
            }
        } else {
            res.json(
                {
                    "msg": "Usuario no existe"
                }
            )
        }
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            {
                msg: "error", details: err
            }
        )
    })
}

// validar si la persona esta registrada 
exports.filterRegistro = (req, res) => {
    const { Op } = require("sequelize");
    Persona.findAll({
        where: {
            [Op.or]: [
                {
                    telefono: req.params.telefono
                }, {
                    dni: req.params.dni
                }
            ]
        }
    }).then(usuario_login => {
        if (usuario_login.length > 0) {
            if (usuario_login[0].dataValues.dni || usuario_login[0].dataValues.telefono) {
                res.json(
                    {
                        "msg": "1",
                        "dni_person": usuario_login[0].dataValues.dni,
                        "nombre_person": usuario_login[0].dataValues.nombres,
                        "telefono_person": usuario_login[0].dataValues.telefono,
                    }
                )
            } else {
                res.json(
                    {
                        "msg": "2"
                    }
                )
            }
        } else {
            res.json(
                {
                    "msg": "3"
                }
            )
        }
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            {
                msg: "error", details: err
            }
        )
    })
}
//validar correo electronico de la base de datos
exports.filterRegistroCorreo = (req, res) => {
    const { Op } = require("sequelize");
    Persona.findAll({
        where: {
            correo: req.params.correo
        }, include: {model: Usuario}
    }).then(usuario_login => {
        if (usuario_login.length > 0) {
            res.json(
                {
                    "msg": "1",
                    "nombre_person": usuario_login[0].dataValues.nombres,
                    "id_usuario": usuario_login[0].dataValues.usuario.idusuario,
                    "username": usuario_login[0].dataValues.usuario.username,
                }
            )
        } else {
            res.json(
                {
                    "msg": "3"
                }
            )
        }
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            {
                msg: "error", details: err
            }
        )
    })
}


// crear Persona
exports.create_persona = (req, res) => {
    var idPersonP;
    var username = req.body.username;
    var password = req.body.password;
    var estado = req.body.estado;
    var utc = req.body.utc;
    Persona.create({
        nombres: req.body.nombres,
        telefono: req.body.telefono,
        correo: req.body.correo,
        dni: req.body.dni,
        fecha_nacimiento: req.body.fecha_nacimiento,
        utc: req.body.utc,
    }).then(persona => {
        idPersonP = persona.idpersona
        personaCreate(persona.idpersona, username, password, estado, utc)
        res.json(persona);
    })
    function personaCreate(idpersona, username, password, estado, utc) {
        Usuario.create({
            idpersona: idpersona,
            username: username,
            password: password,
            estado: estado,
            utc: utc,
        }).then().catch(err => {
            console.log(err)
        });
    }
};

// consulta entre tablas tweet
exports.filterpersonaTweetAll = (req, res) => {
    const { Op } = require("sequelize");
    Tweet.findAll({
        include: [{
            model: Persona,
        },
        ],
    }).then(persona => {
        res.json(persona)
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            {
                msg: "error", details: err
            }
        )
    })
}

// consulta entre tablas tweet -- comentario
exports.filterComentarioTweet = (req, res) => {
    const { Op } = require("sequelize");
    Comentario.findAll({
        where: {
            idtweet: req.params.idtweet
        },
        include: { model: Persona }
    }).then(comentario => {
        res.json(comentario)
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            {
                msg: "error", details: err
            }
        )
    })
}
// tweet de persona logeada - tweet activados 
exports.tweet_persona = (req, res) => {
    Persona.findAll({
        where: {
            idpersona: req.params.idpersona
        },
        include: {
            model: Tweet, where:
                { estado: 'A' },
            order: [
                ['utc', 'ASC'],
            ],
            include: {
                model: Like
            },
        }
    }).then(persona1 => {
        res.json(persona1);
    })
};
// tweet eliminados de forma logica
exports.tweetDesactivado_persona = (req, res) => {
    Persona.findAll({
        where: {
            idpersona: req.params.idpersona
        },
        include: {
            model: Tweet, where:
                { estado: 'E' },
            order: [
                ['utc', 'ASC'],
            ],
            include: {
                model: Like
            },
        }
    }).then(persona1 => {
        res.json(persona1);
    })
};

exports.perfil_persona = (req, res) => {
    Persona.findAll({
        where: {
            idpersona: req.params.idpersona
        },
        include: {
            model: Usuario,
        }
    }).then(perfil_person => {
        res.json(perfil_person);
    })
};

// tweet_persona_amigo muestra los tweet de los amigos en la pagina principal de la aplicacion
exports.tweet_persona_amigo = (req, res) => {
    const { Op } = require("sequelize");
    Amigo.findAll({
        where: {
            idpersona: req.params.idpersona
        },
        include: {
            model: Persona, where: {
                idpersona: { [Op.not]: null }
            }, include: {
                model: Tweet, where: { estado: 'A' }, order: [
                    ['utc', 'ASC'],
                ], include: {

                    model: Like
                },
            }
        }
    })
        .then(person_tweet => {
            res.json(person_tweet);
        })
};

// verifica si el like existe de la persona y el tweet, una ves comprobado me envia un booleano
// true para saber si existe y false para comprobar que no existe
exports.filter_like_existente = (req, res) => {
    const { Op } = require("sequelize");
    Like.findAll({
        where: {
            [Op.and]: [
                { idpersona: req.params.idpersona },
                { idtweet: req.params.idtweet }
            ]
        },
    })
        .then(person_tweet => {
            if (person_tweet.length > 0) {
                res.json(
                    {
                        "msg": "1",
                        "idlike": person_tweet[0].dataValues.idlike,
                        "validar_like": person_tweet[0].dataValues.like_verificar
                    }
                )
            } else {
                res.json(
                    {
                        "msg": "2",
                        "idlike": '0',
                        "validar_like": false

                    }
                )
            }

        })
};
// me envia todos los datos de la tabla historialpersona de las id de persona relacionada

exports.Historialpersona_ = (req, res) => {
    const { Op } = require("sequelize");
    Historialpersona.findAll({
        where: {
            idpersona: req.params.idpersona
        }, order: [
            ['utc', 'ASC'],
        ],
        include: {
            model: Persona
        }
    })
        .then(persona_historial => {
            res.json(persona_historial);
        })
};

// Op.iRegexp, me busca la persona sin importar que escriba en mayuscula, minuscula o que me escriba una
// parte del nombre, me envia toda la lista.

exports.busqueda_persona = (req, res) => {
    const { Op } = require("sequelize");
    Persona.findAll({
        where: {
            nombres: { [Op.iRegexp]: req.params.nombres }
        }, include: { model: Usuario }
    })
        .then(persona_historial => {
            res.json(persona_historial);
        })
};

// validar amigo sirve para comprobar si la persona es o no es amigo, dependiendo del 
// booleano si me envia un true en la aplicacion me a va a mostrar un "dejar de seguir" y
// si es un false la aplicacion me va a mostrar un "seguir"
exports.validaramigopersona = (req, res) => {
    const { Op } = require("sequelize");
    Amigo.findAll({
        where: {
            [Op.and]: [{
                idpersona: req.params.idpersona
            }, {
                idpersonaamigo: req.params.idpersonaamigo
            }]
        }, include: { model: Persona }
    })
        .then(amigo_persona => {
            if (amigo_persona.length > 0) {
                res.json({
                    "validar_amigo": true,
                    "sms": "1"
                });
            } else {
                res.json({
                    "validar_amigo": false,
                    "sms": "2"
                });
            }

        })
};
 
// invitar_personas muestra un limite de 10 personas al RANDOM 
exports.invitar_personas = (req, res) => {
    const { Sequelize, Op } = require("sequelize");
    Persona.findAll({
        order: [
            [Sequelize.literal('RANDOM()')]
        ], limit: 10
    })
        .then(invitarpersona => {
            res.json(invitarpersona);
        })
};
