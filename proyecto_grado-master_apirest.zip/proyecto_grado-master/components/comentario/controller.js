const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Comentario = db.comentario

 
//ingresar datos a la tabla
exports.create = (req, res) => {
    Comentario.create({
        idtweet: req.body.idtweet,
        idpersona: req.body.idpersona,
        nombre: req.body.nombre,
        utc: req.body.utc
    }).then(comentario => {
        res.json(comentario)
    }).catch(err => {
        res.status(500).json({ msg: "error", mensaje: err });
        console.log('mensaje controlado', err)
    });
};

//consultar datos por el id
exports.filter = (req, res) => {
    const id = req.params.idcomentario
    var filter = {}
    if (req.params.idcomentario > 0) {
        filter = {
            where: {
                idcomentario: id
            }
        }
    }
    Comentario.findAll(filter).then(comentario => {
        res.json(comentario);
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            msg: "error", details: err
        });
    });
}

// Consultar todos los datos de la tabla 
exports.findAll = (req, res) => {
    Comentario.findAll()
        .then(comentario=> {
            res.send(comentario);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving data."
            });
        });
};

//Actualizar todos los datos de la tabla
exports.update = (req, res) => {
    Comentario.update({
        idtweet: req.body.idtweet,
        idpersona: req.body.idpersona,
        nombre: req.body.nombre,
        utc: req.body.utc
    },
        {
            where: {
                idcomentario: req.params.idcomentario,
            }
        })
        .then(() => {
            res.status(200).json(req.body);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                msg: "error", details: err
            });
        });
};


//Eliminar un registro de la tabla por id
exports.delete = (req, res) => {
    const id = req.params.idcomentario;
    Comentario.destroy({
        where: {
            idcomentario: id 
            },
    }).then(() => {
        res.status(200).json({
             msg: 'Registro eliminado -> Representante cedula = ' + id 
            });
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            { 
                msg: "error", details: err
        });
    });
};