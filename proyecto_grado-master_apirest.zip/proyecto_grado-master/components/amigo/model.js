module.exports = (sequelize, Sequelize)=> {
    const Amigo = sequelize.define('amigo',{
        idamigo: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        idpersonaamigo: {
            type: Sequelize.INTEGER,
        },
        utc: {
            type: Sequelize.DATE,
        }
    },
    {timestamps: false})
    return Amigo
}