module.exports = (sequelize, Sequelize)=> {
    const Usuario = sequelize.define('usuario',{
        idusuario: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        estado: {
            type: Sequelize.STRING,
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        password: {
            type: Sequelize.STRING,
        },
        username: {
            type: Sequelize.STRING,
        },
        utc: {
            type: Sequelize.DATE,
        }
    },
    {timestamps: false})
    return Usuario
}