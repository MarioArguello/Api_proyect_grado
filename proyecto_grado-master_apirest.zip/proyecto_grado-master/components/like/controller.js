const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Like = db.like

 
//ingresar datos a la tabla
exports.create = (req, res) => {
    Like.create({
        idtweet: req.body.idtweet,
        idpersona: req.body.idpersona,
        utc: req.body.utc,
        like_verificar: req.body.like_verificar
    }).then(like => {
        res.json(like)
    }).catch(err => {
        res.status(500).json({ msg: "error", mensaje: err });
        console.log('mensaje controlado', err)
    });
};

//consultar datos por el id
exports.filter = (req, res) => {
    const id = req.params.idlike
    var filter = {}
    if (req.params.idlike > 0) {
        filter = {
            where: {
                idlike: id
            }
        }
    }
    Like.findAll(filter).then(like => {
        res.json(like);
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            msg: "error", details: err
        });
    });
}

// Consultar todos los datos de la tabla 
exports.findAll = (req, res) => {
    Like.findAll()
        .then(like=> {
            res.send(like);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving data."
            });
        });
};

//Actualizar todos los datos de la tabla
exports.update = (req, res) => {
    Like.update({
        idtweet: req.body.idtweet,
        idpersona: req.body.idpersona,
        utc: req.body.utc,
        like_verificar: req.body.like_verificar
    },
        {
            where: {
                idlike: req.params.idlike,
            }
        })
        .then(() => {
            res.status(200).json(req.body);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                msg: "error", details: err
            });
        });
};


//Eliminar un registro de la tabla por id
exports.delete = (req, res) => {
    const id = req.params.idlike;
    Like.destroy({
        where: {
            idlike: id 
            },
    }).then(() => {
        res.status(200).json({
             msg: 'Registro eliminado -> Like = ' + id 
            });
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            { 
                msg: "error", details: err
        });
    });
};