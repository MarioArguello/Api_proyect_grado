module.exports = (sequelize, Sequelize)=> {
    const Historialpersona = sequelize.define('historialpersona',{
        idhistorial: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        idpersonabusqueda: {
            type: Sequelize.INTEGER,
        },
        utc: {
            type: Sequelize.DATE,
        }
    },
    {timestamps: false})
    return Historialpersona
}