const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Historialpersona = db.historialpersona

 
//ingresar datos a la tabla
exports.create = (req, res) => {
    Historialpersona.create({
        idpersona: req.body.idpersona,
        idpersonabusqueda: req.body.idpersonabusqueda,
        utc: req.body.utc
    }).then(historialpersona => {
        res.json(historialpersona)
    }).catch(err => {
        res.status(500).json({ msg: "error", mensaje: err });
        console.log('mensaje controlado', err)
    });
};

//consultar datos por el id
exports.filter = (req, res) => {
    const id = req.params.idhistorial
    var filter = {}
    if (req.params.idhistorial > 0) {
        filter = {
            where: {
                idhistorial: id
            }
        }
    }
    Historialpersona.findAll(filter).then(historialpersona => {
        res.json(historialpersona);
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            msg: "error", details: err
        });
    });
}

// Consultar todos los datos de la tabla 
exports.findAll = (req, res) => {
    Historialpersona.findAll()
        .then(historialpersona=> {
            res.send(historialpersona);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving data."
            });
        });
};

//Actualizar todos los datos de la tabla
exports.update = (req, res) => {
    Historialpersona.update({
        idpersona: req.body.idpersona,
        idpersonabusqueda: req.body.idpersonabusqueda,
        utc: req.body.utc
    },
        {
            where: {
                idhistorial: req.params.idhistorial,
            }
        })
        .then(() => {
            res.status(200).json(req.body);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                msg: "error", details: err
            });
        });
};


//Eliminar un registro de la tabla por id
exports.delete = (req, res) => {
    const { Op } = require("sequelize");
    Historialpersona.destroy({
        where: {
            [Op.and]:[{
                idpersona:  req.params.idpersona
            },{
                idpersonabusqueda: req.params.idpersonabusqueda
            }]
        },
    }).then(() => {
        res.status(200).json({
             msg: 'Registro eliminado ->'  
            });
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            { 
                msg: "error", details: err
        });
    });
};