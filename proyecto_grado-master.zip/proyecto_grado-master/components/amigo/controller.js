const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Amigo = db.amigo

 
//ingresar datos a la tabla
exports.create = (req, res) => {
    Amigo.create({
        estado: req.body.estado,
        idpersona: req.body.idpersona,
        idpersonaamigo: req.body.idpersonaamigo,
        utc: req.body.utc
    }).then(amigo => {
        res.json(amigo)
    }).catch(err => {
        res.status(500).json({ msg: "error", mensaje: err });
        console.log('mensaje controlado', err)
    });
};

//consultar datos por el id
exports.filter = (req, res) => {
    const id = req.params.idamigo
    var filter = {}
    if (req.params.idamigo > 0) {
        filter = {
            where: {
                idamigo: id
            }
        }
    }
    Amigo.findAll(filter).then(amigo => {
        res.json(amigo);
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            msg: "error", details: err
        });
    });
}

// Consultar todos los datos de la tabla 
exports.findAll = (req, res) => {
    Amigo.findAll()
        .then(amigo=> {
            res.send(amigo);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving data."
            });
        });
};

//Actualizar todos los datos de la tabla
exports.update = (req, res) => {
    Amigo.update({
        estado: req.body.estado,
        idpersona: req.body.idpersona,
        idpersonaamigo: req.body.idpersonaamigo,
        utc: req.body.utc
    },
        {
            where: {
                idamigo: req.params.idamigo,
            }
        })
        .then(() => {
            res.status(200).json(req.body);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                msg: "error", details: err
            });
        });
};


//Eliminar un registro de la tabla por id
exports.delete = (req, res) => {
    const { Op } = require("sequelize");
    Amigo.destroy({
        where: {
            [Op.and]:[{
                idpersona: req.params.idpersona
            },{
                idpersonaamigo: req.params.idpersonaamigo
            }]
        },
    }).then(() => {
        res.status(200).json({
             msg: 'Registro eliminado -> Amigo = '
            });
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            { 
                msg: "error", details: err
        });
    });
};