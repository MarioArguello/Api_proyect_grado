module.exports = (sequelize, Sequelize)=> {
    const Comentario = sequelize.define('comentario',{
        idcomentario: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        idtweet: {
            type: Sequelize.INTEGER,
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        nombre:{
            type: Sequelize.STRING,
        },
        utc: {
            type: Sequelize.DATE,
        }
    },
    {timestamps: false})
    return Comentario
}