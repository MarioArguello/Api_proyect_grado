module.exports = (sequelize, Sequelize)=> {
    const Tweet = sequelize.define('tweet',{
        idtweet: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        contenido: {
            type: Sequelize.STRING,
        },
        estado: {
            type: Sequelize.STRING,
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        utc: {
            type: Sequelize.DATE,
        }
    },
    {timestamps: false})
    return Tweet
}