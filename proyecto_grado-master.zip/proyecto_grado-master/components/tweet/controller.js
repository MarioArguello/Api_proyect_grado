const path = require('path')
const db = require(path.resolve(__dirname, '../../db.config'))
const Tweet = db.tweet


//ingresar datos a la tabla
exports.create = (req, res) => {
    Tweet.create({
        contenido: req.body.contenido,
        estado: req.body.estado,
        idpersona: req.body.idpersona,
        utc: req.body.utc, 
    }).then(Tweet => {
        res.json(Tweet)
    }).catch(err => {
        res.status(500).json({ msg: "error", mensaje: err });
        console.log('mensaje controlado', err)
    });
};

//consultar datos por el id
exports.filter = (req, res) => {
    const id = req.params.idtweet
    var filter = {}
    if (req.params.idtweet > 0) {
        filter = {
            where: {
                idtweet: id
            }
        }
    }
    Tweet.findAll(filter).then(tweet => {
        res.json(tweet);
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            msg: "error", details: err
        });
    });
}

// Consultar todos los datos de la tabla 
exports.findAll = (req, res) => {
    Tweet.findAll()
        .then(tweet => {
            res.send(tweet);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving data."
            });
        });
};

//Actualizar todos los datos de la tabla
exports.update = (req, res) => {
    Tweet.update({
        contenido: req.body.contenido,
        estado: req.body.estado,
        idpersona: req.body.idpersona,
        utc: req.body.utc, 
    },
        {
            where: {
                idtweet: req.params.idtweet,
            }
        })
        .then(() => {
            res.status(200).json(req.body);
        }).catch(err => {
            console.log(err);
            res.status(500).json({
                msg: "error", details: err
            });
        });
};


//Eliminar un registro de la tabla por id
exports.delete = (req, res) => {
    const id = req.params.idtweet;
    Tweet.destroy({
        where: {
            idtweet: id 
            },
    }).then(() => {
        res.status(200).json({
             msg: 'Registro eliminado -> Representante cedula = ' + id 
            });
    }).catch(err => {
        console.log(err);
        res.status(500).json(
            { 
                msg: "error", details: err
        });
    });
};