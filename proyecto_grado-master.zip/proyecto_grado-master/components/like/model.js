module.exports = (sequelize, Sequelize)=> {
    const Like = sequelize.define('like',{
        idlike: {
            type: Sequelize.UUID,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        idtweet: {
            type: Sequelize.INTEGER,
        },
        idpersona: {
            type: Sequelize.INTEGER,
        },
        utc: {
            type: Sequelize.DATE,
        }, like_verificar: {
            type: Sequelize.BOOLEAN,
            defaultValue: false,
          },
    },
    {timestamps: false})
    return Like
}